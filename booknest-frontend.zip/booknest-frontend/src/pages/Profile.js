import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { authAPI } from '../api';
import './Profile.css';

export default function Profile() {
  const { user, updateUser } = useAuth();
  const [tab, setTab] = useState('profile');
  const [profile, setProfile] = useState({ username: '', phone: '' });
  const [addresses, setAddresses] = useState([]);
  const [pwdForm, setPwdForm] = useState({ old_password: '', new_password: '' });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  useEffect(() => {
    if (user) setProfile({ username: user.username || '', phone: user.phone || '' });
    authAPI.getAddresses().then(({ data }) => setAddresses(data)).catch(() => {});
  }, [user]);

  const showMsg = (type, text) => {
    setMessage({ type, text });
    setTimeout(() => setMessage({ type: '', text: '' }), 3000);
  };

  const handleProfileSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await authAPI.updateProfile(profile);
      updateUser(profile);
      showMsg('success', 'Profile updated successfully!');
    } catch { showMsg('error', 'Failed to update profile.'); }
    finally { setSaving(false); }
  };

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await authAPI.changePassword(pwdForm);
      setPwdForm({ old_password: '', new_password: '' });
      showMsg('success', 'Password changed successfully!');
    } catch (err) {
      showMsg('error', err.response?.data?.error || 'Failed to change password.');
    } finally { setSaving(false); }
  };

  const handleDeleteAddress = async (id) => {
    if (!window.confirm('Delete this address?')) return;
    await authAPI.deleteAddress(id);
    setAddresses(addresses.filter(a => a.address_id !== id));
  };

  return (
    <div className="page-wrapper">
      <div className="container">
        <div className="profile-layout">
          {/* Sidebar */}
          <div className="profile-sidebar card">
            <div className="profile-avatar-section">
              <div className="big-avatar">{user?.username?.[0]?.toUpperCase()}</div>
              <h2 className="profile-name">{user?.username}</h2>
              <p className="profile-email">{user?.email}</p>
            </div>
            <nav className="profile-nav">
              {[
                { key: 'profile',   label: '👤 My Profile' },
                { key: 'addresses', label: '📍 Addresses' },
                { key: 'password',  label: '🔒 Password' },
              ].map((item) => (
                <button
                  key={item.key}
                  className={`profile-nav-btn ${tab === item.key ? 'active' : ''}`}
                  onClick={() => setTab(item.key)}
                >
                  {item.label}
                </button>
              ))}
            </nav>
          </div>

          {/* Content */}
          <div className="profile-content card">
            {message.text && (
              <div className={`alert alert-${message.type}`}>{message.text}</div>
            )}

            {/* Profile Tab */}
            {tab === 'profile' && (
              <div>
                <h2 className="content-title">My Profile</h2>
                <form onSubmit={handleProfileSave}>
                  <div className="form-group">
                    <label className="form-label">Full Name</label>
                    <input className="form-input" type="text"
                      value={profile.username}
                      onChange={(e) => setProfile({ ...profile, username: e.target.value })}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Email</label>
                    <input className="form-input" type="email" value={user?.email} disabled />
                    <p className="field-note">Email cannot be changed</p>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Phone</label>
                    <input className="form-input" type="tel"
                      value={profile.phone}
                      onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                    />
                  </div>
                  <button type="submit" className="btn btn-primary" disabled={saving}>
                    {saving ? 'Saving…' : 'Save Changes'}
                  </button>
                </form>
              </div>
            )}

            {/* Addresses Tab */}
            {tab === 'addresses' && (
              <div>
                <h2 className="content-title">Saved Addresses</h2>
                {addresses.length === 0 ? (
                  <p className="no-data">No addresses saved yet.</p>
                ) : (
                  <div className="addresses-grid">
                    {addresses.map((addr) => (
                      <div key={addr.address_id} className="addr-card">
                        <strong>{addr.full_name}</strong>
                        <p>{addr.house_no}, {addr.street}</p>
                        <p>{addr.city}, {addr.state} - {addr.pincode}</p>
                        <p>{addr.country}</p>
                        <p>📞 {addr.phone}</p>
                        <button
                          className="btn btn-danger"
                          style={{ marginTop: 10, fontSize: '0.8rem', padding: '5px 12px' }}
                          onClick={() => handleDeleteAddress(addr.address_id)}
                        >
                          Delete
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Password Tab */}
            {tab === 'password' && (
              <div>
                <h2 className="content-title">Change Password</h2>
                <form onSubmit={handlePasswordChange} style={{ maxWidth: 400 }}>
                  <div className="form-group">
                    <label className="form-label">Current Password</label>
                    <input className="form-input" type="password"
                      value={pwdForm.old_password}
                      onChange={(e) => setPwdForm({ ...pwdForm, old_password: e.target.value })}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">New Password</label>
                    <input className="form-input" type="password"
                      value={pwdForm.new_password}
                      onChange={(e) => setPwdForm({ ...pwdForm, new_password: e.target.value })}
                      minLength={8}
                      required
                    />
                  </div>
                  <button type="submit" className="btn btn-primary" disabled={saving}>
                    {saving ? 'Updating…' : 'Update Password'}
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
